export type GameMode = "idle" | "running" | "stageResult" | "finished";

export type GameMetrics = {
  progress: number;
  stability: number;
  debt: number;
};

export type ProblemTag =
  | "spec"
  | "bug"
  | "tutorial"
  | "fun"
  | "economy"
  | "leadership"
  | "release"
  | "regression"
  | "combat"
  | "acceptance";

export type Stage = {
  id: string;
  title: string;
  index: number;
  problemIds: string[];
};

export type Problem = {
  id: string;
  title: string;
  description: string;
  tags: ProblemTag[];
  severity: 1 | 2 | 3;
  decisionIds: string[];
};

export type DecisionTone = "fast" | "safe" | "risky" | "repair";

export type DecisionCard = {
  id: string;
  title: string;
  description: string;
  effects: Partial<GameMetrics>;
  resultText: string;
  tone: DecisionTone;
};

export type UpgradeId = "serverRoom" | "qaDepartment" | "canteen";

export type Upgrade = {
  id: UpgradeId;
  title: string;
  description: string;
  effectLabel: string;
  maxLevel: number;
  baseCost: number;
  costStep: number;
};

export type UpgradeLevels = Record<UpgradeId, number>;

export type RunResult = "gold" | "rough" | "collapsed" | "rejected";

export type RunResultCopy = {
  title: string;
  description: string;
  stamp: string;
};

export type GameState = {
  mode: GameMode;
  currentStageIndex: number;
  currentProblemId: string | null;
  metrics: GameMetrics;
  budget: number;
  upgradeLevels: UpgradeLevels;
  log: string;
  result: RunResult | null;
  canteenUsed: boolean;
  selectedDecisionId: string | null;
  lastReward: number;
  runNumber: number;
};
