import {
  AlertTriangle,
  BadgeCheck,
  Hammer,
  Play,
  RotateCcw,
  ShieldCheck,
  Wrench,
  Zap,
} from "lucide-react";
import { useMemo, useState } from "react";
import {
  BALANCE,
  PROOF_GAME_DECISIONS,
  PROOF_GAME_PROBLEMS,
  PROOF_GAME_STAGES,
  PROOF_GAME_UPGRADES,
  RUN_RESULT_COPY,
} from "../data/proofGameData";
import {
  applyDecision,
  calculateReward,
  clampMetrics,
  createInitialMetrics,
  evaluateRunResult,
  getUpgradeCost,
  INITIAL_UPGRADE_LEVELS,
} from "../lib/proofGameRules";
import type { DecisionCard, GameMetrics, GameMode, GameState, RunResult, Upgrade } from "../types/game";

const metricOrder: Array<keyof GameMetrics> = ["progress", "stability", "debt"];

const metricLabels: Record<keyof GameMetrics, string> = {
  progress: "Прогресс",
  stability: "Стабильность",
  debt: "Техдолг",
};

const modeLabels: Record<GameMode, string> = {
  idle: "Ожидание приказа",
  running: "Забег активен",
  stageResult: "Последствие",
  finished: "Цикл закрыт",
};

const resultToneClasses: Record<RunResult, string> = {
  gold: "border-amber-300/50 bg-amber-300/10 text-amber-50",
  rough: "border-orange-300/40 bg-orange-300/10 text-orange-50",
  collapsed: "border-red-400/50 bg-red-950/50 text-red-50",
  rejected: "border-red-300/40 bg-red-950/40 text-red-50",
};

function pickProblemId(stageIndex: number) {
  const stage = PROOF_GAME_STAGES[stageIndex] ?? PROOF_GAME_STAGES[0];
  const randomIndex = Math.floor(Math.random() * stage.problemIds.length);

  return stage.problemIds[randomIndex] ?? PROOF_GAME_PROBLEMS[0].id;
}

function createInitialGameState(): GameState {
  return {
    mode: "idle",
    currentStageIndex: 0,
    currentProblemId: null,
    metrics: createInitialMetrics(INITIAL_UPGRADE_LEVELS),
    budget: 0,
    upgradeLevels: INITIAL_UPGRADE_LEVELS,
    log: "Терминал КБ-42 ждет приказа. Бюджетный цикл не открыт.",
    result: null,
    canteenUsed: false,
    selectedDecisionId: null,
    lastReward: 0,
    runNumber: 0,
  };
}

function signedValue(value: number) {
  return value > 0 ? `+${value}` : String(value);
}

function isPositiveEffect(metric: keyof GameMetrics, value: number) {
  if (metric === "debt") {
    return value < 0;
  }

  return value > 0;
}

function summarizeDelta(delta: GameMetrics) {
  const parts = metricOrder
    .filter((metric) => delta[metric] !== 0)
    .map((metric) => `${metricLabels[metric]} ${signedValue(delta[metric])}`);

  return parts.length > 0 ? parts.join(", ") : "без изменений";
}

function MetricGauge({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "amber" | "green" | "red";
}) {
  const roundedValue = Math.round(value);
  const barClass =
    tone === "red"
      ? "bg-red-500"
      : tone === "green"
        ? "bg-emerald-400"
        : "bg-amber-300";
  const textClass =
    tone === "red"
      ? "text-red-200"
      : tone === "green"
        ? "text-emerald-200"
        : "text-amber-100";

  return (
    <div className="rounded-lg border border-amber-100/15 bg-black/25 p-3">
      <div className="mb-2 flex items-center justify-between gap-3 font-mono text-[11px] uppercase tracking-[0.18em] text-amber-100/70">
        <span>{label}</span>
        <span className={textClass}>{roundedValue}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-zinc-800 ring-1 ring-amber-100/10">
        <div
          className={`h-full rounded-full ${barClass}`}
          style={{ width: `${Math.max(0, Math.min(100, roundedValue))}%` }}
        />
      </div>
    </div>
  );
}

function DecisionButton({
  decision,
  disabled,
  selected,
  onSelect,
}: {
  decision: DecisionCard;
  disabled: boolean;
  selected: boolean;
  onSelect: () => void;
}) {
  const toneClass =
    decision.tone === "risky"
      ? "border-red-800/50 hover:border-red-700"
      : decision.tone === "repair"
        ? "border-emerald-800/40 hover:border-emerald-700"
        : decision.tone === "safe"
          ? "border-amber-800/40 hover:border-amber-700"
          : "border-orange-800/40 hover:border-orange-700";

  return (
    <button
      type="button"
      disabled={disabled}
      aria-pressed={selected}
      onClick={onSelect}
      className={`min-h-[172px] rounded-lg border bg-stone-100 p-4 text-left text-stone-950 shadow-[0_10px_30px_rgba(0,0,0,0.2)] transition hover:-translate-y-0.5 hover:bg-amber-50 focus:outline-none focus:ring-4 focus:ring-amber-300/25 disabled:cursor-not-allowed disabled:hover:translate-y-0 ${toneClass} ${
        selected ? "ring-2 ring-red-500/70" : disabled ? "opacity-70" : ""
      }`}
    >
      <div className="mb-3 flex items-start justify-between gap-3 border-b border-stone-900/10 pb-3">
        <div>
          <p className="font-mono text-[10px] font-semibold uppercase tracking-[0.2em] text-red-900/70">
            Бланк решения
          </p>
          <h5 className="mt-1 text-lg font-black leading-6 text-stone-950">{decision.title}</h5>
        </div>
        <span className="mt-1 h-3 w-3 shrink-0 rounded-full border border-red-900/40 bg-red-700/80" />
      </div>
      <p className="text-sm leading-6 text-stone-800">{decision.description}</p>
      <div className="mt-4 flex flex-wrap gap-1.5">
        {metricOrder.map((metric) => {
          const value = decision.effects[metric];

          if (!value) {
            return null;
          }

          const positive = isPositiveEffect(metric, value);

          return (
            <span
              key={metric}
              className={`rounded border px-2 py-1 font-mono text-[11px] font-semibold ${
                positive
                  ? "border-emerald-900/20 bg-emerald-100 text-emerald-900"
                  : "border-red-900/20 bg-red-100 text-red-900"
              }`}
            >
              {metricLabels[metric]} {signedValue(value)}
            </span>
          );
        })}
      </div>
    </button>
  );
}

function UpgradeRow({
  upgrade,
  level,
  budget,
  locked,
  onBuy,
}: {
  upgrade: Upgrade;
  level: number;
  budget: number;
  locked: boolean;
  onBuy: () => void;
}) {
  const cost = getUpgradeCost(upgrade, level);
  const isMaxed = cost === null;
  const disabled = locked || isMaxed || budget < (cost ?? 0);

  return (
    <div className="rounded-lg border border-amber-100/15 bg-zinc-950/70 p-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-amber-200/60">
            Уровень {level}/{upgrade.maxLevel}
          </p>
          <h5 className="mt-1 text-base font-semibold text-amber-50">{upgrade.title}</h5>
          <p className="mt-2 text-sm leading-6 text-amber-100/70">{upgrade.description}</p>
          <p className="mt-2 font-mono text-[11px] uppercase tracking-[0.12em] text-red-200/80">
            {upgrade.effectLabel}
          </p>
        </div>
        <button
          type="button"
          disabled={disabled}
          onClick={onBuy}
          className="inline-flex min-h-10 shrink-0 items-center justify-center gap-2 rounded border border-amber-200/25 bg-amber-200 px-3 py-2 text-sm font-black text-zinc-950 transition hover:bg-amber-100 focus:outline-none focus:ring-4 focus:ring-amber-300/20 disabled:cursor-not-allowed disabled:border-amber-100/10 disabled:bg-zinc-800 disabled:text-amber-100/40"
        >
          <Wrench className="h-4 w-4" aria-hidden="true" />
          {isMaxed ? "МАКС" : `${cost} Б`}
        </button>
      </div>
    </div>
  );
}

export function ProofGame() {
  const [state, setState] = useState<GameState>(() => createInitialGameState());

  const problemById = useMemo(
    () => new Map(PROOF_GAME_PROBLEMS.map((problem) => [problem.id, problem])),
    [],
  );
  const decisionById = useMemo(
    () => new Map(PROOF_GAME_DECISIONS.map((decision) => [decision.id, decision])),
    [],
  );

  const currentStage = PROOF_GAME_STAGES[state.currentStageIndex] ?? PROOF_GAME_STAGES[0];
  const currentProblem = state.currentProblemId ? problemById.get(state.currentProblemId) : null;
  const decisions =
    currentProblem?.decisionIds
      .map((decisionId) => decisionById.get(decisionId))
      .filter((decision): decision is DecisionCard => Boolean(decision)) ?? [];
  const runNumber = state.runNumber > 0 ? String(state.runNumber).padStart(2, "0") : "00";
  const resultCopy = state.result ? RUN_RESULT_COPY[state.result] : null;
  const upgradeLocked = state.mode === "running" || state.mode === "stageResult";
  const canteenLevel = state.upgradeLevels.canteen;
  const canUseCanteen = state.mode === "running" && canteenLevel > 0 && !state.canteenUsed;

  function startRun() {
    setState((current) => ({
      ...current,
      mode: "running",
      currentStageIndex: 0,
      currentProblemId: pickProblemId(0),
      metrics: createInitialMetrics(current.upgradeLevels),
      log: "Приказ принят. КБ-42 запускает производственный цикл.",
      result: null,
      canteenUsed: false,
      selectedDecisionId: null,
      lastReward: 0,
      runNumber: current.runNumber + 1,
    }));
  }

  function selectDecision(decisionId: string) {
    setState((current) => {
      if (current.mode !== "running" || !current.currentProblemId) {
        return current;
      }

      const problem = problemById.get(current.currentProblemId);
      const decision = decisionById.get(decisionId);

      if (!problem || !decision) {
        return current;
      }

      const applied = applyDecision({
        metrics: current.metrics,
        problem,
        decision,
        upgradeLevels: current.upgradeLevels,
      });
      const reachedFinalStage = current.currentStageIndex === PROOF_GAME_STAGES.length - 1;
      const result = evaluateRunResult(applied.metrics, reachedFinalStage);
      const deltaText = summarizeDelta(applied.delta);
      const baseLog = `${decision.resultText} Итог: ${deltaText}.${
        applied.falloutText ? ` ${applied.falloutText}` : ""
      }`;

      if (result) {
        const reward = calculateReward(result, applied.metrics);

        return {
          ...current,
          mode: "finished",
          metrics: applied.metrics,
          budget: current.budget + reward,
          log: `${baseLog} ${RUN_RESULT_COPY[result].title}: бюджет +${reward}.`,
          result,
          selectedDecisionId: decisionId,
          lastReward: reward,
        };
      }

      return {
        ...current,
        mode: "stageResult",
        metrics: applied.metrics,
        log: baseLog,
        selectedDecisionId: decisionId,
      };
    });
  }

  function advanceStage() {
    setState((current) => {
      if (current.mode !== "stageResult") {
        return current;
      }

      const nextStageIndex = current.currentStageIndex + 1;

      return {
        ...current,
        mode: "running",
        currentStageIndex: nextStageIndex,
        currentProblemId: pickProblemId(nextStageIndex),
        log: `Цикл ${nextStageIndex + 1}/7. На пульт поступила новая сводка.`,
        selectedDecisionId: null,
      };
    });
  }

  function useCanteen() {
    setState((current) => {
      const level = current.upgradeLevels.canteen;

      if (current.mode !== "running" || level <= 0 || current.canteenUsed) {
        return current;
      }

      const bonus = level * BALANCE.canteenStabilityBonus;
      const metrics = clampMetrics({
        ...current.metrics,
        stability: current.metrics.stability + bonus,
      });
      const actualBonus = metrics.stability - current.metrics.stability;

      return {
        ...current,
        metrics,
        canteenUsed: true,
        log: `Столовая выдала компот и строгий взгляд завхоза. Стабильность +${actualBonus}.`,
      };
    });
  }

  function buyUpgrade(upgrade: Upgrade) {
    setState((current) => {
      if (current.mode === "running" || current.mode === "stageResult") {
        return current;
      }

      const currentLevel = current.upgradeLevels[upgrade.id];
      const cost = getUpgradeCost(upgrade, currentLevel);

      if (cost === null || current.budget < cost) {
        return current;
      }

      return {
        ...current,
        budget: current.budget - cost,
        upgradeLevels: {
          ...current.upgradeLevels,
          [upgrade.id]: currentLevel + 1,
        },
        log: `Модернизация КБ: ${upgrade.title} повышена до уровня ${currentLevel + 1}.`,
      };
    });
  }

  return (
    <div className="rounded-xl border border-white/10 bg-slate-950/75 p-2 shadow-[0_22px_70px_rgba(0,0,0,0.34)]">
      <div className="relative overflow-hidden rounded-lg border border-amber-100/20 bg-zinc-950 text-amber-50 shadow-[inset_0_0_80px_rgba(0,0,0,0.72)]">
        <div className="pointer-events-none absolute inset-0 opacity-35 [background:radial-gradient(circle_at_18%_8%,rgba(248,113,113,0.2),transparent_26rem),radial-gradient(circle_at_80%_0%,rgba(251,191,36,0.12),transparent_24rem)]" />
        <div className="pointer-events-none absolute inset-0 opacity-[0.08] [background-image:linear-gradient(rgba(251,191,36,0.55)_1px,transparent_1px),linear-gradient(90deg,rgba(251,191,36,0.55)_1px,transparent_1px)] [background-size:28px_28px]" />
        <div className="pointer-events-none absolute inset-0 opacity-[0.07] [background:repeating-linear-gradient(0deg,transparent_0px,transparent_3px,rgba(255,255,255,0.75)_4px)]" />

        <div className="relative z-10 p-4 sm:p-6 lg:p-7">
          <div className="flex flex-col gap-5 border-b border-amber-100/15 pb-5 xl:flex-row xl:items-start xl:justify-between">
            <div className="max-w-3xl">
              <div className="mb-3 flex flex-wrap items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-amber-200/70">
                <span className="rounded border border-red-300/25 bg-red-950/40 px-2.5 py-1 text-red-100">
                  КБ-42
                </span>
                <span className="rounded border border-amber-200/20 bg-black/25 px-2.5 py-1">
                  Сборка {runNumber}
                </span>
                <span className="rounded border border-amber-200/20 bg-black/25 px-2.5 py-1">
                  {modeLabels[state.mode]}
                </span>
              </div>
              <h3 className="text-3xl font-black leading-tight text-amber-50 sm:text-4xl">
                КБ-42: Красный Билд
              </h3>
              <p className="mt-3 max-w-2xl text-[16px] leading-7 text-amber-100/80">
                Карточный one-more-run прототип про билд, костыли, техдолг и попытку пройти
                Госприёмку без развала проекта.
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row xl:flex-col xl:items-end">
              <div className="rounded-lg border border-amber-200/20 bg-black/40 px-4 py-3">
                <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-amber-200/60">
                  Бюджет
                </p>
                <p className="mt-1 text-3xl font-black text-amber-200">{state.budget} Б</p>
              </div>

              {state.mode === "idle" ? (
                <button
                  type="button"
                  onClick={startRun}
                  className="inline-flex min-h-12 items-center justify-center gap-2 rounded border border-red-300/40 bg-red-700 px-5 py-3 text-sm font-black uppercase tracking-[0.12em] text-red-50 transition hover:bg-red-600 focus:outline-none focus:ring-4 focus:ring-red-300/20"
                >
                  <Play className="h-4 w-4" aria-hidden="true" />
                  Начать забег
                </button>
              ) : state.mode === "stageResult" ? (
                <button
                  type="button"
                  onClick={advanceStage}
                  className="inline-flex min-h-12 items-center justify-center gap-2 rounded border border-amber-300/40 bg-amber-200 px-5 py-3 text-sm font-black uppercase tracking-[0.12em] text-zinc-950 transition hover:bg-amber-100 focus:outline-none focus:ring-4 focus:ring-amber-300/20"
                >
                  <Zap className="h-4 w-4" aria-hidden="true" />
                  Следующий этап
                </button>
              ) : state.mode === "finished" ? (
                <button
                  type="button"
                  onClick={startRun}
                  className="inline-flex min-h-12 items-center justify-center gap-2 rounded border border-amber-300/40 bg-amber-200 px-5 py-3 text-sm font-black uppercase tracking-[0.12em] text-zinc-950 transition hover:bg-amber-100 focus:outline-none focus:ring-4 focus:ring-amber-300/20"
                >
                  <RotateCcw className="h-4 w-4" aria-hidden="true" />
                  Новый забег
                </button>
              ) : (
                <button
                  type="button"
                  disabled
                  className="inline-flex min-h-12 items-center justify-center gap-2 rounded border border-amber-100/10 bg-zinc-900 px-5 py-3 text-sm font-black uppercase tracking-[0.12em] text-amber-100/50"
                >
                  <AlertTriangle className="h-4 w-4" aria-hidden="true" />
                  Выберите решение
                </button>
              )}
            </div>
          </div>

          <div className="mt-6 grid gap-5 xl:grid-cols-[minmax(0,1.12fr)_minmax(320px,0.88fr)]">
            <div className="space-y-4">
              <div className="rounded-lg border border-red-300/25 bg-red-950/25 p-4">
                <div className="mb-3 flex flex-wrap items-center gap-2 font-mono text-[11px] uppercase tracking-[0.18em] text-red-100/85">
                  <span className="rounded border border-red-200/25 bg-red-950/50 px-2.5 py-1">
                    Цикл {currentStage.index}/{PROOF_GAME_STAGES.length}
                  </span>
                  <span className="rounded border border-amber-200/20 bg-black/25 px-2.5 py-1 text-amber-100/75">
                    {currentStage.title}
                  </span>
                </div>

                {currentProblem ? (
                  <>
                    <p className="font-mono text-xs uppercase tracking-[0.24em] text-red-200/70">
                      Аварийная сводка
                    </p>
                    <h4 className="mt-2 text-2xl font-black leading-8 text-red-50">
                      {currentProblem.title}
                    </h4>
                    <p className="mt-3 text-[16px] leading-7 text-red-50/80">
                      {currentProblem.description}
                    </p>
                  </>
                ) : (
                  <>
                    <p className="font-mono text-xs uppercase tracking-[0.24em] text-amber-200/70">
                      Пульт ожидания
                    </p>
                    <h4 className="mt-2 text-2xl font-black leading-8 text-amber-50">
                      Производственный цикл не запущен
                    </h4>
                    <p className="mt-3 text-[16px] leading-7 text-amber-100/70">
                      Нажмите старт, чтобы получить первую проблему и три решения.
                    </p>
                  </>
                )}
              </div>

              <div className="grid gap-3 md:grid-cols-3 xl:grid-cols-3">
                {decisions.length > 0 ? (
                  decisions.map((decision) => (
                    <DecisionButton
                      key={decision.id}
                      decision={decision}
                      disabled={state.mode !== "running"}
                      selected={state.selectedDecisionId === decision.id}
                      onSelect={() => selectDecision(decision.id)}
                    />
                  ))
                ) : (
                  <div className="rounded-lg border border-amber-100/15 bg-black/30 p-5 text-[16px] leading-7 text-amber-100/70 md:col-span-3">
                    Карточки решений появятся после старта забега.
                  </div>
                )}
              </div>

              <div className="rounded-lg border border-amber-200/20 bg-black/50 p-4">
                <div className="mb-2 flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.2em] text-amber-200/60">
                  <Hammer className="h-3.5 w-3.5" aria-hidden="true" />
                  Лента телетайпа
                </div>
                <p className="font-mono text-sm leading-7 text-amber-100">{state.log}</p>
              </div>

              {resultCopy && state.result ? (
                <div className={`rounded-lg border p-5 ${resultToneClasses[state.result]}`}>
                  <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
                    <p className="font-mono text-[11px] uppercase tracking-[0.24em] opacity-75">
                      Финальный штамп
                    </p>
                    <span className="rotate-[-3deg] rounded border border-current px-3 py-1 font-mono text-xs font-black uppercase tracking-[0.18em]">
                      {resultCopy.stamp}
                    </span>
                  </div>
                  <h4 className="text-2xl font-black">{resultCopy.title}</h4>
                  <p className="mt-2 text-[16px] leading-7 opacity-85">{resultCopy.description}</p>
                  <p className="mt-4 font-mono text-sm uppercase tracking-[0.16em]">
                    Начислено: +{state.lastReward} Бюджета
                  </p>
                </div>
              ) : null}
            </div>

            <aside className="space-y-4">
              <div className="rounded-lg border border-amber-100/15 bg-black/30 p-4">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-amber-200/60">
                      Приборная панель
                    </p>
                    <h4 className="mt-1 text-lg font-semibold text-amber-50">Индикаторы сборки</h4>
                  </div>
                  <ShieldCheck className="h-5 w-5 text-amber-200/70" aria-hidden="true" />
                </div>

                <div className="space-y-3">
                  <MetricGauge label="Прогресс" value={state.metrics.progress} tone="amber" />
                  <MetricGauge
                    label="Стабильность билда"
                    value={state.metrics.stability}
                    tone="green"
                  />
                  <MetricGauge label="Техдолг" value={state.metrics.debt} tone="red" />
                </div>

                <button
                  type="button"
                  disabled={!canUseCanteen}
                  onClick={useCanteen}
                  className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded border border-amber-200/20 bg-zinc-900 px-4 py-2 text-sm font-semibold text-amber-100 transition hover:border-amber-200/50 hover:bg-amber-200/10 focus:outline-none focus:ring-4 focus:ring-amber-300/15 disabled:cursor-not-allowed disabled:text-amber-100/40"
                >
                  <BadgeCheck className="h-4 w-4" aria-hidden="true" />
                  {canteenLevel > 0
                    ? state.canteenUsed
                      ? "Столовая уже помогла"
                      : `Перерыв в столовой +${canteenLevel * BALANCE.canteenStabilityBonus}`
                    : "Столовая не модернизирована"}
                </button>
              </div>

              <div className="rounded-lg border border-amber-100/15 bg-zinc-950/80 p-4">
                <div className="mb-4 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-red-200/70">
                      Модернизация КБ
                    </p>
                    <h4 className="mt-1 text-lg font-semibold text-amber-50">Улучшения между забегами</h4>
                  </div>
                  <Wrench className="h-5 w-5 text-red-200/75" aria-hidden="true" />
                </div>

                {upgradeLocked ? (
                  <p className="mb-3 rounded border border-red-300/20 bg-red-950/25 px-3 py-2 font-mono text-xs uppercase tracking-[0.14em] text-red-100/75">
                    Цех закрыт до конца текущего цикла
                  </p>
                ) : null}

                <div className="space-y-3">
                  {PROOF_GAME_UPGRADES.map((upgrade) => (
                    <UpgradeRow
                      key={upgrade.id}
                      upgrade={upgrade}
                      level={state.upgradeLevels[upgrade.id]}
                      budget={state.budget}
                      locked={upgradeLocked}
                      onBuy={() => buyUpgrade(upgrade)}
                    />
                  ))}
                </div>
              </div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  );
}
