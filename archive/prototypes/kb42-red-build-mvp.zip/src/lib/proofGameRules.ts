import { BALANCE } from "../data/proofGameData";
import type { DecisionCard, GameMetrics, Problem, RunResult, Upgrade, UpgradeLevels } from "../types/game";

export const INITIAL_UPGRADE_LEVELS: UpgradeLevels = {
  serverRoom: 0,
  qaDepartment: 0,
  canteen: 0,
};

type ApplyDecisionInput = {
  metrics: GameMetrics;
  problem: Problem;
  decision: DecisionCard;
  upgradeLevels: UpgradeLevels;
};

type AppliedDecision = {
  metrics: GameMetrics;
  delta: GameMetrics;
  falloutText: string;
};

function clamp(value: number, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value));
}

export function clampMetrics(metrics: GameMetrics): GameMetrics {
  return {
    progress: clamp(metrics.progress),
    stability: clamp(metrics.stability),
    debt: clamp(metrics.debt),
  };
}

export function createInitialMetrics(upgradeLevels: UpgradeLevels): GameMetrics {
  return {
    progress: BALANCE.startProgress,
    stability: clamp(
      BALANCE.startStability + upgradeLevels.serverRoom * BALANCE.serverRoomStabilityBonus,
    ),
    debt: 0,
  };
}

function addMetrics(metrics: GameMetrics, delta: Partial<GameMetrics>): GameMetrics {
  return clampMetrics({
    progress: metrics.progress + (delta.progress ?? 0),
    stability: metrics.stability + (delta.stability ?? 0),
    debt: metrics.debt + (delta.debt ?? 0),
  });
}

function getDebtFallout(
  metrics: GameMetrics,
  problem: Problem,
  decision: DecisionCard,
  upgradeLevels: UpgradeLevels,
) {
  let stabilityLoss = 0;
  let progressLoss = 0;

  if (metrics.debt >= 70) {
    stabilityLoss = 13 + problem.severity * 2;
    progressLoss = problem.tags.some((tag) => tag === "release" || tag === "regression") ? 5 : 3;
  } else if (metrics.debt >= 45) {
    stabilityLoss = 8 + problem.severity;
  } else if (metrics.debt >= 25) {
    stabilityLoss = 4;
  }

  const qaRelevant = problem.tags.some(
    (tag) => tag === "bug" || tag === "regression" || tag === "release",
  );
  const qaMitigation = qaRelevant ? upgradeLevels.qaDepartment * BALANCE.qaMitigationPerLevel : 0;
  const decisionMitigation = decision.id === "qa-pass" && qaRelevant ? 6 : 0;
  stabilityLoss = Math.max(0, stabilityLoss - qaMitigation - decisionMitigation);

  const text =
    stabilityLoss > 0 || progressLoss > 0
      ? `Техдолг дал отдачу: -${stabilityLoss} стабильности${
          progressLoss > 0 ? `, -${progressLoss} прогресса` : ""
        }.`
      : "";

  return { stabilityLoss, progressLoss, text };
}

export function applyDecision({
  metrics,
  problem,
  decision,
  upgradeLevels,
}: ApplyDecisionInput): AppliedDecision {
  const afterDecision = addMetrics(metrics, decision.effects);
  const fallout = getDebtFallout(afterDecision, problem, decision, upgradeLevels);
  const nextMetrics = addMetrics(afterDecision, {
    stability: -fallout.stabilityLoss,
    progress: -fallout.progressLoss,
  });

  return {
    metrics: nextMetrics,
    delta: {
      progress: nextMetrics.progress - metrics.progress,
      stability: nextMetrics.stability - metrics.stability,
      debt: nextMetrics.debt - metrics.debt,
    },
    falloutText: fallout.text,
  };
}

export function evaluateRunResult(
  metrics: GameMetrics,
  reachedFinalStage: boolean,
): RunResult | null {
  if (metrics.stability <= 0) {
    return "collapsed";
  }

  if (!reachedFinalStage) {
    return null;
  }

  if (metrics.progress >= 85 && metrics.stability >= 45 && metrics.debt <= 35) {
    return "gold";
  }

  if (metrics.progress >= 70 && metrics.stability > 0) {
    return "rough";
  }

  return "rejected";
}

export function calculateReward(result: RunResult, metrics: GameMetrics) {
  const base = BALANCE.rewardBase[result];
  const bonus =
    Math.floor(metrics.progress / 25) +
    Math.floor(Math.max(metrics.stability, 0) / 40) -
    Math.floor(metrics.debt / 50);

  return Math.max(1, base + bonus);
}

export function getUpgradeCost(upgrade: Upgrade, currentLevel: number) {
  if (currentLevel >= upgrade.maxLevel) {
    return null;
  }

  return upgrade.baseCost + currentLevel * upgrade.costStep;
}
